package xin.justcsl.seventh.db;

import org.litepal.crud.LitePalSupport;

public class County extends LitePalSupport
{
    private Integer countyId;
    private String countyName;
    private String countyCode;

    private String weatherId;

    private Integer cityId;

    public Integer getCountyId()
    {
        return countyId;
    }

    public void setCountyId(Integer countyId)
    {
        this.countyId = countyId;
    }

    public String getCountyName()
    {
        return countyName;
    }

    public void setCountyName(String countyName)
    {
        this.countyName = countyName;
    }

    public String getCountyCode()
    {
        return countyCode;
    }

    public void setCountyCode(String countyCode)
    {
        this.countyCode = countyCode;
    }

    public String getWeatherId()
    {
        return weatherId;
    }

    public void setWeatherId(String weatherId)
    {
        this.weatherId = weatherId;
    }

    public Integer getCityId()
    {
        return cityId;
    }

    public void setCityId(Integer cityId)
    {
        this.cityId = cityId;
    }
}
